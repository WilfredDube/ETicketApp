package com.unbusy.e_ticketapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Filter;
import android.widget.ListView;

import java.util.ArrayList;

public class SelectStationsActivity extends AppCompatActivity {
    private static final String TAG = "SelectStationsActivity";
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_stations);

        Toolbar toolbar	= findViewById(R.id.topPanel);
        toolbar.setTitleTextColor(getResources().getColor(R.color.colorWhite, null));
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        TripData tripData = (TripData) intent.getSerializableExtra("trip_data");

        ListView stationList = findViewById(R.id.stationList);

        Station station1 = new Station("NRZ Bulwayo Main", "Bulawayo", "Bulawayo", "Bulawayo");
        Station station2 = new Station("Ngamo", "Mat North", "Bulawayo", "Hwange");
        Station station3 = new Station("Mpopoma", "Bulawayo", "Bulawayo", "Bulawayo");
        Station station4 = new Station("Luveve", "Bulawayo", "Bulawayo", "Bulawayo");
        Station station5 = new Station("Dete", "Mat North", "Bulawayo", "Hwange");
        Station station6 = new Station("NRZ Hwange", "Hwange", "Bulawayo", "Hwange");

        final ArrayList<Station> stations = new ArrayList<>();

        stations.add(station1);
        stations.add(station2);
        stations.add(station3);
        stations.add(station4);
        stations.add(station5);
        stations.add(station6);

//
//        for (int i = 0; i < stations.size(); i++){
//            if ((stations.get(i).getStName() == tripData.getFromPlace()) || (stations.get(i).getStName() == tripData.getToPlace())
//                    || (stations.get(i).getBetweenTown_one() == tripData.getToPlace()) || (stations.get(i).getBetweenTown_one() == tripData.getFromPlace())
//                    || (stations.get(i).getBetweenTown_two() == tripData.getToPlace()) || (stations.get(i).getBetweenTown_two() == tripData.getFromPlace())) {
//
//            } else if(stations.get(i).getStLocation() == tripData.getToPlace()) {
//                stations.remove(i);
//            }
//        }

        StationListAdapter stationListAdapter = new StationListAdapter(this, R.layout.station_list_item, stations);
        stationList.setAdapter(stationListAdapter);

        Log.d(TAG, "onCreate: " + tripData.getTrainName());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}
