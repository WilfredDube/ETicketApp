package com.unbusy.e_ticketapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private ListView tripListView;

    // e531 lenovo
    @Override
    protected void onCreate(Bundle savedInstanceState) {       
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: MAIN ACTIVITY");
        setContentView(R.layout.activity_sign_in);
//
//        Toolbar toolbar	= findViewById(R.id.topPanel);
//        toolbar.setTitleTextColor(getResources().getColor(R.color.colorWhite, null));
//        setSupportActionBar(toolbar);

    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        return super.onOptionsItemSelected(item);
//    }
}
